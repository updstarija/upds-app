export const keysStorage = {
  SAW_WELCOME_SCREEN: "SAW_WELCOME_SCREEN",
  JWT_TOKEN: "JWT_TOKEN"
};

