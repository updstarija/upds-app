export interface IResponseModuloProyeccion {
    status: number;
    data: Modulo[];
}

export interface Modulo {
    id: number;
    nombre: string;
}
