export interface IResponseRegistroMateria {
    aula: string;
    costo: string;
    cupo: string;
    docente: string;
    grupo: string;
    materia: string;
    semestre: string;
    turno: string;
}
