export interface ISemestre {
    id: number
    nombre: string
}