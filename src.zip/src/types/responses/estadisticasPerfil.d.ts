
export interface IResponsePromedio {
    status: number;
    data: {
        promedio: number
    }
}

export interface IResponseProgreso {
    status: number;
    data: {
        progreso: number
    }
}

