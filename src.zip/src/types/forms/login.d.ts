export interface IFormLogin {
    usuario: string
    contraseña: string
}