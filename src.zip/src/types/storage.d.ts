export type TUploadFile = {
  filename: string;
  url: string;
  ref: string;
};
