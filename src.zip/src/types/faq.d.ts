export interface IFaq {
    id: string;
    titulo: string;
    categoria: string;
    descripcion: string;
}