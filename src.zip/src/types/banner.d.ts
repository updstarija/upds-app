export type Banner = {
    id: string,
    enlace: string,
    estado: boolean,
    fecha: Date,
    hora: string,
    imagen: string
    posicion: number
}