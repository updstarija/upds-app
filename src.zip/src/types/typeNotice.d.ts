export type INotificacionNotice = {
  id: string,
  categoria: string,
  fecha: string,
  imagen: string,
  like: number,
  pie: string,
  prioridad: string,
  texto: string,
  titulo: string,
  url: string
}