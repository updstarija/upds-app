import { View, Text } from 'react-native'
import React from 'react'

const DetalleMateria = () => {
    return (
        <View>
            <Text>DetalleMateria</Text>
        </View>
    )
}

export default DetalleMateria