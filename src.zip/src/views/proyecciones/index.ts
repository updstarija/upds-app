export { default as DetalleBoleta } from './DetalleBoleta';
export { default as DetalleMateriasSemestre } from './DetalleMateriasSemestre';
export { default as MateriaProyeccionesItem } from './MateriaProyeccionesItem';
export { default as SemestreProyeccionItem } from './SemestreProyeccionItem';
export { default as SelectModulos } from './SelectModulos';
export * from "./RequisitoMateria"
export * from "./Busqueda"

