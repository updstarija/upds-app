import React from 'react'

const VideoPlayer = () => {
  return (
    <div>VideoPlayer</div>
  )
}

export default VideoPlayer